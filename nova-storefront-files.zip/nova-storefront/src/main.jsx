import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { createClient } from "@supabase/supabase-js";
import "./styles.css";

const env = import.meta.env;
const supabase = createClient(env.VITE_SUPABASE_URL, env.VITE_SUPABASE_ANON_KEY);
const productsUrl = env.VITE_NOVA_PRODUCTS_FUNCTION;
const checkoutUrl = env.VITE_NOVA_CHECKOUT_FUNCTION;

const money = (value) =>
  new Intl.NumberFormat("en-ZA", { style: "currency", currency: "ZAR" }).format(Number(value || 0));

function App() {
  const [products, setProducts] = useState([]);
  const [category, setCategory] = useState("all");
  const [cart, setCart] = useState(() => JSON.parse(localStorage.getItem("nova-cart") || "[]"));
  const [session, setSession] = useState(null);
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(true);
  const [checkoutBusy, setCheckoutBusy] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    loadProducts();
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    localStorage.setItem("nova-cart", JSON.stringify(cart));
  }, [cart]);

  async function loadProducts() {
    setLoading(true);
    try {
      const res = await fetch(`${productsUrl}?category=${encodeURIComponent(category)}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Unable to load products");
      setProducts(data);
    } catch (e) {
      setMessage(e.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadProducts(); }, [category]);

  const categories = useMemo(
    () => ["all", ...new Set(products.map((p) => p.category).filter(Boolean))],
    [products]
  );

  const cartCount = cart.reduce((n, item) => n + item.quantity, 0);
  const subtotal = cart.reduce((n, item) => n + Number(item.price_zar) * item.quantity, 0);

  function add(product) {
    setCart((current) => {
      const found = current.find((x) => x.product_id === product.id);
      if (found) {
        return current.map((x) => x.product_id === product.id
          ? { ...x, quantity: Math.min(x.quantity + 1, product.stock) } : x);
      }
      return [...current, { product_id: product.id, name: product.name, price_zar: product.price_zar, quantity: 1, stock: product.stock }];
    });
    setMessage(`${product.name} added to cart.`);
  }

  function remove(id) {
    setCart((current) => current.filter((x) => x.product_id !== id));
  }

  function updateQty(id, quantity) {
    setCart((current) => current.map((x) => x.product_id === id
      ? { ...x, quantity: Math.max(1, Math.min(Number(quantity), x.stock)) } : x));
  }

  async function signIn() {
    setMessage("");
    if (!email) return setMessage("Enter your email first.");
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: window.location.origin }
    });
    setMessage(error ? error.message : "Check your email for the secure Nova sign-in link.");
  }

  async function checkout() {
    setMessage("");
    if (!session) return setMessage("Sign in before checkout.");
    if (!cart.length) return setMessage("Your cart is empty.");
    setCheckoutBusy(true);
    try {
      const { data: { session: current } } = await supabase.auth.getSession();
      const res = await fetch(checkoutUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${current.access_token}`
        },
        body: JSON.stringify({
          items: cart.map((x) => ({ product_id: x.product_id, quantity: x.quantity })),
          payment_provider: "payfast",
          address: {}
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Checkout failed");
      setCart([]);
      setMessage(`Order ${data.order_id} created. Total: ${money(data.total_zar)}.`);
    } catch (e) {
      setMessage(e.message);
    } finally {
      setCheckoutBusy(false);
    }
  }

  return (
    <div className="page">
      <header className="header">
        <a className="brand" href="#">NOVA</a>
        <nav>
          <a href="#shop">Shop</a>
          <a href="#about">About</a>
          <span className="cart-pill">Cart {cartCount}</span>
        </nav>
      </header>

      <main>
        <section className="hero">
          <div>
            <p className="eyebrow">NOVA / EVERYDAY GOODS</p>
            <h1>Objects for a quieter, better everyday.</h1>
            <p className="hero-copy">Thoughtful pieces for home, carry and daily ritual.</p>
            <a className="button dark" href="#shop">Shop collection</a>
          </div>
        </section>

        <section id="shop" className="shop">
          <div className="section-head">
            <div>
              <p className="eyebrow">THE COLLECTION</p>
              <h2>Selected essentials</h2>
            </div>
            <div className="filters">
              {categories.map((c) => (
                <button className={category === c ? "filter active" : "filter"} key={c} onClick={() => setCategory(c)}>
                  {c}
                </button>
              ))}
            </div>
          </div>

          {loading ? <p>Loading collection…</p> : (
            <div className="grid">
              {products.map((p) => (
                <article className="card" key={p.id}>
                  <div className="image-wrap">
                    {p.image_url ? <img src={p.image_url} alt={p.name} /> : <div className="placeholder">NOVA</div>}
                  </div>
                  <div className="card-info">
                    <div>
                      <h3>{p.name}</h3>
                      <p>{p.description || "Considered everyday goods."}</p>
                    </div>
                    <strong>{money(p.price_zar)}</strong>
                  </div>
                  <button className="button" disabled={!p.stock} onClick={() => add(p)}>
                    {p.stock ? "Add to cart" : "Sold out"}
                  </button>
                </article>
              ))}
            </div>
          )}
        </section>

        <section className="commerce" id="cart">
          <div>
            <p className="eyebrow">YOUR CART</p>
            <h2>Ready when you are.</h2>
            {cart.length ? cart.map((item) => (
              <div className="cart-row" key={item.product_id}>
                <div><strong>{item.name}</strong><span>{money(item.price_zar)}</span></div>
                <input type="number" min="1" max={item.stock} value={item.quantity}
                  onChange={(e) => updateQty(item.product_id, e.target.value)} />
                <button onClick={() => remove(item.product_id)}>Remove</button>
              </div>
            )) : <p>Your cart is empty.</p>}
            <div className="total"><span>Subtotal</span><strong>{money(subtotal)}</strong></div>
          </div>

          <aside className="checkout">
            <p className="eyebrow">SECURE ACCOUNT</p>
            {session ? (
              <>
                <p>Signed in as <strong>{session.user.email}</strong></p>
                <button className="button dark full" disabled={checkoutBusy || !cart.length} onClick={checkout}>
                  {checkoutBusy ? "Creating order…" : "Continue to checkout"}
                </button>
                <button className="link-button" onClick={() => supabase.auth.signOut()}>Sign out</button>
              </>
            ) : (
              <>
                <p>Sign in with a magic link to continue securely.</p>
                <input className="input" type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} />
                <button className="button dark full" onClick={signIn}>Send sign-in link</button>
              </>
            )}
            {message && <p className="message">{message}</p>}
          </aside>
        </section>

        <section id="about" className="about">
          <p className="eyebrow">NOVA</p>
          <h2>Less noise. Better things.</h2>
          <p>Nova is a modern commerce storefront backed by Supabase, designed to grow from a focused collection into a scalable six-figure business.</p>
        </section>
      </main>

      <footer>© {new Date().getFullYear()} Nova</footer>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
